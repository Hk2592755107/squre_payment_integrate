<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Square\SquareClient;
use Square\Types\Money;
use Square\Payments\Requests\CreatePaymentRequest;
use Square\Exceptions\SquareApiException;
use Square\Exceptions\SquareException;
use App\Models\Payment;

class SquarePaymentController extends Controller
{

    private SquareClient $squareClient;

    public function __construct()
    {
        // CORRECT WAY: Direct string values, not using env() in array
        $accessToken = env('SQUARE_ACCESS_TOKEN');
        $environment = env('SQUARE_ENVIRONMENT', 'sandbox');

        Log::info('Square Config', [
            'token_length' => strlen($accessToken),
            'environment' => $environment
        ]);

        // SquareClient expects separate arguments, not array
        $this->squareClient = new SquareClient($accessToken, $environment);
    }

    /**
     * Show payment form
     */
    public function showPaymentForm()
    {
        $appId = env('SQUARE_APPLICATION_ID');
        $locationId = env('SQUARE_LOCATION_ID');

        Log::info('Loading payment form', [
            'app_id_set' => !empty($appId),
            'location_id_set' => !empty($locationId)
        ]);

        return view('payment', [
            'app_id' => $appId,
            'location_id' => $locationId
        ]);
    }

    /**
     * Process payment and save to database
     */
    public function processPayment(Request $request)
    {
        Log::info('Payment process started', [
            'amount' => $request->amount,
            'has_source_id' => !empty($request->sourceId)
        ]);

        // Simple validation
        $validator = Validator::make($request->all(), [
            'sourceId' => 'required|string',
            'amount' => 'required|numeric|min:0.5',
        ]);

        if ($validator->fails()) {
            Log::error('Validation failed', $validator->errors()->toArray());
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {

            // Convert amount to cents
            $amountInCents = (int) round($request->amount * 100);

            // Create money object
            $money = new Money();
            $money->setAmount($amountInCents);
            $money->setCurrency('USD');

            // Create idempotency key
            $idempotencyKey = 'pay_' . uniqid();

            // Create payment request
            $paymentRequest = new CreatePaymentRequest(
                $request->sourceId,
                $idempotencyKey,
                $money
            );

            $locationId = env('SQUARE_LOCATION_ID');
            $paymentRequest->setLocationId($locationId);
            $paymentRequest->setNote('Payment for order #' . uniqid());

            Log::info('Sending payment to Square', [
                'amount_cents' => $amountInCents,
                'location_id' => $locationId
            ]);

            // Execute payment
            $response = $this->squareClient->payments($paymentRequest);

            if ($response->isSuccess()) {
                $payment = $response->getResult()->getPayment();
                Log::info('Square payment successful', [
                    'payment_id' => $payment->getId(),
                    'status' => $payment->getStatus()
                ]);

                // Save to database
                $paymentRecord = Payment::create([
                    'square_payment_id' => $payment->getId(),
                    'amount' => $request->amount,
                    'currency' => 'USD',
                    'status' => $payment->getStatus(),
                    'customer_email' => $request->customer_email ?? 'test@example.com',
                    'order_id' => $request->order_id ?? 'order_' . uniqid(),
                    'payment_data' => json_encode($this->convertPaymentToArray($payment)),
                    'request_data' => json_encode($request->all()),
                    'idempotency_key' => $idempotencyKey,
                    'location_id' => $locationId
                ]);

                return response()->json([
                    'success' => true,
                    'message' => 'Payment processed successfully',
                    'data' => [
                        'payment_id' => $payment->getId(),
                        'status' => $payment->getStatus(),
                        'amount' => $request->amount,
                        'record_id' => $paymentRecord->id
                    ]
                ]);

            } else {
                $errors = $response->getErrors();
                Log::error('Square payment failed', $errors);

                return response()->json([
                    'success' => false,
                    'message' => 'Payment processing failed',
                    'errors' => $errors
                ], 400);
            }

        } catch (SquareApiException $e) {
            Log::error('Square API Exception', [
                'message' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Square API Error',
                'error' => $e->getMessage()
            ], 500);

        } catch (\Exception $e) {
            Log::error('General Exception', [
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Something went wrong',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    /**
     * Convert Square payment object to array
     */
    private function convertPaymentToArray($payment)
    {
        return [
            'id' => $payment->getId(),
            'created_at' => $payment->getCreatedAt(),
            'updated_at' => $payment->getUpdatedAt(),
            'amount_money' => [
                'amount' => $payment->getTotalMoney()->getAmount(),
                'currency' => $payment->getTotalMoney()->getCurrency()
            ],
            'status' => $payment->getStatus(),
            'source_type' => $payment->getSourceType(),
            'customer_id' => $payment->getCustomerId(),
            'order_id' => $payment->getOrderId(),
            'reference_id' => $payment->getReferenceId(),
            'note' => $payment->getNote(),
            'location_id' => $payment->getLocationId(),
            'app_fee_money' => $payment->getAppFeeMoney() ? [
                'amount' => $payment->getAppFeeMoney()->getAmount(),
                'currency' => $payment->getAppFeeMoney()->getCurrency()
            ] : null,
            'approved_money' => $payment->getApprovedMoney() ? [
                'amount' => $payment->getApprovedMoney()->getAmount(),
                'currency' => $payment->getApprovedMoney()->getCurrency()
            ] : null,
            'receipt_number' => $payment->getReceiptNumber(),
            'receipt_url' => $payment->getReceiptUrl(),
            'risk_evaluation' => $payment->getRiskEvaluation() ? [
                'created_at' => $payment->getRiskEvaluation()->getCreatedAt(),
                'risk_level' => $payment->getRiskEvaluation()->getRiskLevel()
            ] : null
        ];
    }

    /**
     * Prepare complete response data
     */
    private function prepareResponseData($paymentRecord, $paymentData)
    {
        return [
            'payment_record' => [
                'id' => $paymentRecord->id,
                'square_payment_id' => $paymentRecord->square_payment_id,
                'amount' => $paymentRecord->amount,
                'currency' => $paymentRecord->currency,
                'status' => $paymentRecord->status,
                'customer_email' => $paymentRecord->customer_email,
                'order_id' => $paymentRecord->order_id,
                'note' => $paymentRecord->note,
                'source_type' => $paymentRecord->source_type,
                'created_at' => $paymentRecord->created_at->toDateTimeString(),
                'updated_at' => $paymentRecord->updated_at->toDateTimeString(),
                'formatted_amount' => $paymentRecord->currency . ' ' . number_format($paymentRecord->amount, 2),
                'is_successful' => $paymentRecord->isSuccessful()
            ],
            'square_payment_data' => $paymentData,
            'additional_info' => [
                'environment' => env('SQUARE_ENVIRONMENT'),
                'location_id' => env('SQUARE_LOCATION_ID'),
                'receipt_url' => $paymentData['receipt_url'] ?? null
            ]
        ];
    }

    /**
     * Get or create customer in Square
     */
    private function getOrCreateCustomer($email)
    {
        try {
            $customersApi = $this->squareClient->getCustomersApi();

            // Search for existing customer
            $response = $customersApi->searchCustomers([
                'query' => [
                    'filter' => [
                        'email_address' => [
                            'exact' => $email
                        ]
                    ]
                ]
            ]);

            if ($response->isSuccess() && !empty($response->getResult()->getCustomers())) {
                return $response->getResult()->getCustomers()[0]->getId();
            }

            // Create new customer
            $createResponse = $customersApi->createCustomer([
                'email_address' => $email,
                'given_name' => 'Customer',
                'family_name' => substr($email, 0, strpos($email, '@'))
            ]);

            if ($createResponse->isSuccess()) {
                return $createResponse->getResult()->getCustomer()->getId();
            }

        } catch (\Exception $e) {
            \Log::error('Customer creation error: ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Payment success page
     */
    public function paymentSuccess($paymentId)
    {
        $payment = Payment::where('square_payment_id', $paymentId)->first();

        if (!$payment) {
            return redirect()->route('payment.failed');
        }

        return view('payment_success', [
            'payment' => $payment,
            'square_data' => $payment->payment_data
        ]);
    }

    /**
     * Payment failed page
     */
    public function paymentFailed()
    {
        return view('payment_failed');
    }

    /**
     * Get all payments (for testing)
     */
    public function getAllPayments()
    {
        $payments = Payment::orderBy('created_at', 'desc')->get();

        return response()->json([
            'success' => true,
            'data' => [
                'payments' => $payments,
                'total' => $payments->count(),
                'successful' => $payments->where('status', 'COMPLETED')->count(),
                'failed' => $payments->where('status', 'FAILED')->count()
            ]
        ]);
    }

    /**
     * Get payment details by ID
     */
    public function getPaymentDetails($id)
    {
        $payment = Payment::find($id);

        if (!$payment) {
            return response()->json([
                'success' => false,
                'message' => 'Payment not found',
                'data' => null
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => [
                'payment_record' => $payment,
                'square_payment_data' => $payment->payment_data,
                'request_data' => $payment->request_data
            ]
        ]);
    }

    /**
     * Test Square connection
     */
    public function testConnection()
    {
        try {
            $locationsApi = $this->squareClient->getLocationsApi();
            $response = $locationsApi->listLocations();

            if ($response->isSuccess()) {
                $locations = $response->getResult()->getLocations();
                return response()->json([
                    'success' => true,
                    'message' => 'Square connection successful',
                    'locations' => count($locations),
                    'environment' => env('SQUARE_ENVIRONMENT')
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'error' => $response->getErrors()
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

}
