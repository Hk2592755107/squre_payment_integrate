<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SquarePaymentController;
Route::get('/', function () {
    return view('welcome');
});



// Payment Routes
Route::get('/', [SquarePaymentController::class, 'showPaymentForm'])->name('payment.form');
Route::post('/process-payment', [SquarePaymentController::class, 'processPayment'])->name('payment.process');
Route::get('/payment/success/{paymentId}', [SquarePaymentController::class, 'paymentSuccess'])->name('payment.success');
Route::get('/payment/failed', [SquarePaymentController::class, 'paymentFailed'])->name('payment.failed');

// API Routes for getting data
Route::get('/payments', [SquarePaymentController::class, 'getAllPayments'])->name('payments.all');
Route::get('/payment/{id}', [SquarePaymentController::class, 'getPaymentDetails'])->name('payment.details');
