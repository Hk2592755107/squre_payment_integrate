<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Square Payment</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f7f7f7; padding: 20px; }
        .container { max-width: 500px; margin: 40px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; margin-bottom: 20px; }
        input { width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 4px; border: 1px solid #ccc; }
        button { width: 100%; padding: 12px; background: #0077cc; color: white; font-weight: bold; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #005fa3; }
        #payment-result { margin-top: 20px; }
        .text-green { color: green; }
        .text-red { color: red; }
    </style>
</head>
<body>

<div class="container">
    <h2>Square Payment</h2>

    <label for="amount">Enter Amount ($):</label>
    <input type="number" id="amount" min="1" value="10">

    <div id="card-container"></div>

    <button id="card-button">Pay Now</button>

    <div id="payment-result"></div>
</div>

<!-- Square JS SDK -->
<script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', async () => {
        const payments = Square.payments(
            "<?php echo e(env('SQUARE_APPLICATION_ID')); ?>",
            "<?php echo e(env('SQUARE_LOCATION_ID')); ?>"
        );

        const card = await payments.card();
        await card.attach('#card-container');

        const amountInput = document.getElementById('amount');
        const resultDiv = document.getElementById('payment-result');

        document.getElementById('card-button').addEventListener('click', async () => {
            resultDiv.innerHTML = '';

            const amount = parseFloat(amountInput.value);
            if (isNaN(amount) || amount < 1) {
                resultDiv.innerHTML = '<p class="text-red">Please enter a valid amount.</p>';
                return;
            }

            try {
                const result = await card.tokenize();

                if (result.status === 'OK') {
                    const response = await fetch('/square-pay', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ nonce: result.token, amount })
                    });

                    const data = await response.json();

                    if (data.success) {
                        resultDiv.innerHTML = `
                        <p class="text-green"><strong>Payment Successful!</strong></p>
                        <p>Payment ID: ${data.payment.payment_id}</p>
                        <p>Status: ${data.payment.status}</p>
                        <p>Amount: $${(data.payment.amount/100).toFixed(2)}</p>
                    `;
                    } else {
                        console.error(data.errors || data.exception);
                        resultDiv.innerHTML = '<p class="text-red"><strong>Payment Failed. Check console for details.</strong></p>';
                    }

                } else {
                    resultDiv.innerHTML = '<p class="text-red"><strong>Card tokenization failed. Try again.</strong></p>';
                }

            } catch(err) {
                console.error(err);
                resultDiv.innerHTML = '<p class="text-red"><strong>An error occurred. Check console.</strong></p>';
            }
        });
    });
</script>

</body>
</html>
<?php /**PATH E:\Hussain khan\backend\Practice\square_integrate\resources\views/square-payment.blade.php ENDPATH**/ ?>