<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Square Payment Integration</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #006aff 0%, #0051cc 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
        }

        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .header p {
            opacity: 0.9;
            font-size: 16px;
        }

        .payment-form {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 14px;
        }

        input, select {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #006aff;
            background: white;
            box-shadow: 0 0 0 3px rgba(0, 106, 255, 0.1);
        }

        .amount-input {
            position: relative;
        }

        .amount-input::before {
            content: '$';
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            font-weight: bold;
            z-index: 1;
        }

        .amount-input input {
            padding-left: 30px;
        }

        #card-container {
            margin: 20px 0;
            border: 2px solid #e1e5e9;
            padding: 20px;
            border-radius: 8px;
            background: #f8f9fa;
            min-height: 80px;
            transition: all 0.3s ease;
        }

        #card-container:hover {
            border-color: #006aff;
        }

        #card-button {
            width: 100%;
            background: linear-gradient(135deg, #006aff 0%, #0051cc 100%);
            color: white;
            padding: 18px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 106, 255, 0.3);
        }

        #card-button:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 106, 255, 0.4);
        }

        #card-button:active {
            transform: translateY(0);
        }

        #card-button:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .message {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .loading {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .test-cards {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin-top: 25px;
            font-size: 14px;
        }

        .test-cards h3 {
            color: #856404;
            margin-bottom: 10px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .test-cards ul {
            list-style: none;
            padding-left: 0;
        }

        .test-cards li {
            padding: 5px 0;
            color: #856404;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .test-cards li::before {
            content: '•';
            color: #856404;
            font-weight: bold;
        }

        .payment-details {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            border: 1px solid #e1e5e9;
        }

        .payment-details h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .response-data {
            background: #2d3748;
            color: #e2e8f0;
            padding: 15px;
            border-radius: 6px;
            margin-top: 15px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            max-height: 200px;
            overflow-y: auto;
            display: none;
        }

        .toggle-response {
            background: none;
            border: 1px solid #006aff;
            color: #006aff;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .toggle-response:hover {
            background: #006aff;
            color: white;
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #ffffff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 14px;
            border-top: 1px solid #e1e5e9;
            background: #f8f9fa;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .container {
                border-radius: 10px;
            }

            .payment-form {
                padding: 20px;
            }

            .header {
                padding: 20px 15px;
            }

            .header h1 {
                font-size: 24px;
            }
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-row .form-group {
            flex: 1;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>💳 Secure Payment</h1>
        <p>Complete your purchase safely and securely</p>
    </div>

    <div class="payment-form">
        <form id="payment-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="amount">Amount (USD)</label>
                    <div class="amount-input">
                        <input type="number" id="amount" name="amount" value="10.00" min="1" step="0.01" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="customer_email">Email Address</label>
                    <input type="email" id="customer_email" name="customer_email" placeholder="your@email.com">
                </div>
            </div>

            <div class="form-group">
                <label for="order_id">Order ID (Optional)</label>
                <input type="text" id="order_id" name="order_id" placeholder="Order reference">
            </div>

            <div class="payment-details">
                <h3>🔒 Card Information</h3>
                <div id="card-container"></div>
            </div>

            <button type="button" id="card-button" disabled>
                <span id="button-text">Process Payment - $10.00</span>
            </button>

            <div id="message"></div>

            <div class="payment-details" id="response-section" style="display: none;">
                <h3>📊 Payment Response</h3>
                <button type="button" class="toggle-response" onclick="toggleResponse()">Show Response Data</button>
                <div class="response-data" id="response-data"></div>
            </div>
        </form>

        <div class="test-cards">
            <h3>💡 Test Card Information</h3>
            <ul>
                <li><strong>Card Number:</strong> 4111 1111 1111 1111</li>
                <li><strong>Expiry Date:</strong> 12/2025</li>
                <li><strong>CVV:</strong> 123</li>
                <li><strong>ZIP Code:</strong> 12345</li>
            </ul>
            <p style="margin-top: 10px; font-style: italic;">Use these test details to simulate a payment</p>
        </div>
    </div>

    <div class="footer">
        <p>🔒 Your payment information is secure and encrypted</p>
        <p>Powered by Square Payments</p>
    </div>
</div>

<script>
    // Square configuration
    const appId = '{{ $app_id }}';
    const locationId = '{{ $location_id }}';

    let payments;
    let card;
    let lastResponseData = null;

    // Initialize Square payment system
    async function initializeSquare() {
        try {
            if (!window.Square) {
                throw new Error('Square.js failed to load. Please check your internet connection.');
            }

            // Initialize Square payments
            payments = window.Square.payments(appId, locationId);

            // Create and attach card element
            card = await payments.card();
            await card.attach('#card-container');

            // Enable pay button
            document.getElementById('card-button').disabled = false;

            showMessage('✅ Payment form is ready! Enter your card details above.', 'success');

            // Update button amount when amount changes
            document.getElementById('amount').addEventListener('input', updateButtonAmount);

        } catch (error) {
            console.error('Square initialization error:', error);
            showMessage('❌ Error initializing payment system. Please refresh the page.', 'error');
        }
    }

    // Update button amount text
    function updateButtonAmount() {
        const amount = document.getElementById('amount').value;
        const buttonText = document.getElementById('button-text');
        buttonText.textContent = `Process Payment - $${amount}`;
    }

    // Tokenize card details
    async function tokenizeCard() {
        try {
            const result = await card.tokenize();
            if (result.status === 'OK') {
                return result.token;
            } else {
                throw new Error(`Card tokenization failed: ${result.status}`);
            }
        } catch (error) {
            console.error('Tokenization error:', error);
            throw error;
        }
    }

    // Show message to user
    function showMessage(message, type) {
        const messageDiv = document.getElementById('message');
        messageDiv.className = `message ${type}`;
        messageDiv.innerHTML = message;

        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                if (messageDiv.className.includes('success')) {
                    messageDiv.style.display = 'none';
                }
            }, 5000);
        }
    }

    // Toggle response data visibility
    function toggleResponse() {
        const responseData = document.getElementById('response-data');
        const toggleBtn = document.querySelector('.toggle-response');

        if (responseData.style.display === 'none' || responseData.style.display === '') {
            responseData.style.display = 'block';
            toggleBtn.textContent = 'Hide Response Data';
            if (lastResponseData) {
                responseData.textContent = JSON.stringify(lastResponseData, null, 2);
            }
        } else {
            responseData.style.display = 'none';
            toggleBtn.textContent = 'Show Response Data';
        }
    }

    // Show response data
    function showResponseData(data) {
        lastResponseData = data;
        const responseSection = document.getElementById('response-section');
        responseSection.style.display = 'block';

        // Log to console for debugging
        console.log('Payment Response:', data);
    }

    // Handle payment button click
    document.getElementById('card-button').addEventListener('click', async function() {
        const button = this;
        const buttonText = document.getElementById('button-text');
        const originalText = buttonText.textContent;

        // Get form values
        const amount = document.getElementById('amount').value;
        const customerEmail = document.getElementById('customer_email').value;
        const orderId = document.getElementById('order_id').value;

        // Validate amount
        if (!amount || amount < 1) {
            showMessage('❌ Please enter a valid amount (minimum $1)', 'error');
            return;
        }

        if (!customerEmail) {
            showMessage('❌ Please enter your email address', 'error');
            return;
        }

        // Update button to show loading state
        button.disabled = true;
        buttonText.innerHTML = '<div class="loading-spinner"></div> Processing Payment...';
        showMessage('🔄 Processing your payment... Please wait.', 'loading');

        try {
            // Tokenize card details
            const token = await tokenizeCard();

            // Prepare request data
            const requestData = {
                sourceId: token,
                amount: parseFloat(amount),
                customer_email: customerEmail,
                order_id: orderId || 'order_' + Date.now(),
                note: 'Payment for order #' + Math.random().toString(36).substr(2, 9)
            };

            // Send payment request to server
            const response = await fetch('/process-payment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify(requestData)
            });

            const data = await response.json();

            if (data.success) {
                showMessage('✅ ' + (data.message || 'Payment processed successfully!'), 'success');
                showResponseData(data.data);

                // Redirect to success page after 3 seconds
                setTimeout(() => {
                    if (data.data && data.data.payment_record) {
                        window.location.href = `/payment/success/${data.data.payment_record.square_payment_id}`;
                    }
                }, 3000);

            } else {
                const errorMsg = data.errors ?
                    (typeof data.errors === 'string' ? data.errors : JSON.stringify(data.errors)) :
                    (data.error || 'Unknown error occurred');

                showMessage('❌ Payment failed: ' + errorMsg, 'error');
                showResponseData(data);
            }

        } catch (error) {
            console.error('Payment processing error:', error);
            showMessage('❌ Error processing payment: ' + error.message, 'error');
        } finally {
            // Reset button state
            button.disabled = false;
            buttonText.textContent = originalText;
        }
    });

    // Form validation
    document.getElementById('amount').addEventListener('blur', function() {
        const amount = parseFloat(this.value);
        if (amount < 1) {
            showMessage('❌ Amount must be at least $1', 'error');
        } else if (amount > 10000) {
            showMessage('⚠️ Large amount detected. Please confirm.', 'info');
        }
    });

    document.getElementById('customer_email').addEventListener('blur', function() {
        const email = this.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email && !emailRegex.test(email)) {
            showMessage('❌ Please enter a valid email address', 'error');
        }
    });

    // Initialize Square when page loads
    document.addEventListener('DOMContentLoaded', function() {
        initializeSquare();
        updateButtonAmount(); // Set initial button amount
    });

    // Prevent form submission
    document.getElementById('payment-form').addEventListener('submit', function(e) {
        e.preventDefault();
    });
</script>
</body>
</html>
